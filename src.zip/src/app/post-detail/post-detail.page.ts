import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { PIonicService } from '../shared/p-ionic.service';

@Component({
  selector: 'app-post-detail',
  templateUrl: './post-detail.page.html',
  styleUrls: ['./post-detail.page.scss'],
})
export class PostDetailPage implements OnInit {
  postDetial: any;
 
  constructor(
    private activatedRoute: ActivatedRoute, 
    private pService: PIonicService, 
  ) { }

  ngOnInit() {
    let id = this.activatedRoute.snapshot.paramMap.get('id');
    this.pService.postDetails(id).subscribe((data) => {
      this.postDetial = data;
    });
  }

  goToOrgPost() {
    window.open(this.postDetial.link, '_blank');
  }  

}
