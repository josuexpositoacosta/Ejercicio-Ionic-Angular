

export const URL_SERVICIOS =  'http://localhost:3000/'; // 'https://gorest.co.in/public/v2/users/'; 