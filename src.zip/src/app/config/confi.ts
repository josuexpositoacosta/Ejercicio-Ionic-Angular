

export const URL_SERVICIOS_ACTUAL = 'http://localhost:4200';