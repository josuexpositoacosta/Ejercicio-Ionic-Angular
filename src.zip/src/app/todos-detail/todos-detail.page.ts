import { Component, OnInit } from '@angular/core';

import { ActivatedRoute } from '@angular/router';
import { TIonicService } from '../shared/t-ionic.service';

@Component({
  selector: 'app-todos-detail',
  templateUrl: './todos-detail.page.html',
  styleUrls: ['./todos-detail.page.scss'],
})
export class TodosDetailPage implements OnInit {
  todosDetails: any;
 
  constructor(
    private activatedRoute: ActivatedRoute, 
    private tService: TIonicService, 
  ) { }

  ngOnInit() {
    let id = this.activatedRoute.snapshot.paramMap.get('id');
    this.tService.todosDetails(id).subscribe((data) => {
      this.todosDetails = data;
    });
  }

  goToOrgTodos() {
    window.open(this.todosDetails.link, '_blank');
  }  

}
