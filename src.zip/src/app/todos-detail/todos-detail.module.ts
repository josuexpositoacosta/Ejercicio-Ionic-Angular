import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { TodosDetailPageRoutingModule } from './todos-detail-routing.module';

import { TodosDetailPage } from './todos-detail.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    TodosDetailPageRoutingModule
  ],
  declarations: [TodosDetailPage]
})
export class TodosDetailPageModule {}
