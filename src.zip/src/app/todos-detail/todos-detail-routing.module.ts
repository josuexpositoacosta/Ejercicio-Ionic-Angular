import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { TodosDetailPage } from './todos-detail.page';

const routes: Routes = [
  {
    path: '',
    component: TodosDetailPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class TodosDetailPageRoutingModule {}
