import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { CommentsDetailPageRoutingModule } from './comments-detail-routing.module';

import { CommentsDetailPage } from './comments-detail.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    CommentsDetailPageRoutingModule
  ],
  declarations: [CommentsDetailPage]
})
export class CommentsDetailPageModule {}
