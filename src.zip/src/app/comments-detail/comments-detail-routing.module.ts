import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CommentsDetailPage } from './comments-detail.page';

const routes: Routes = [
  {
    path: '',
    component: CommentsDetailPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CommentsDetailPageRoutingModule {}
