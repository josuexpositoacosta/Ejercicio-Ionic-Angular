import { Component, OnInit } from '@angular/core';

import { ActivatedRoute } from '@angular/router';
import { CIonicService } from '../shared/c-ionic.service';


@Component({
  selector: 'app-comments-detail',
  templateUrl: './comments-detail.page.html',
  styleUrls: ['./comments-detail.page.scss'],
})
export class CommentsDetailPage implements OnInit {
  commentsDetial: any;

  constructor(
    private activatedRoute: ActivatedRoute, 
    private cService: CIonicService, 
  ) { }

  ngOnInit() {
    let id = this.activatedRoute.snapshot.paramMap.get('id');
    this.cService.commentsDetails(id).subscribe((data) => {
      this.commentsDetial = data;
    });
  }
  goToOrgComments() {
    window.open(this.commentsDetial.link, '_blank');
  }  

}
