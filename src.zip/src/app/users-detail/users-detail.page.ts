import { Component, OnInit } from '@angular/core';

import { ActivatedRoute } from '@angular/router';
import { UIonicService } from '../shared/u-ionic.service';

@Component({
  selector: 'app-users-detail',
  templateUrl: './users-detail.page.html',
  styleUrls: ['./users-detail.page.scss'],
})
export class UsersDetailPage implements OnInit {

  usersDetails: any;
 
  constructor(
    private activatedRoute: ActivatedRoute, 
    private uService: UIonicService, 
  ) { }

  ngOnInit() {
    let id = this.activatedRoute.snapshot.paramMap.get('id');
    this.uService.usersDetails(id).subscribe((data) => {
      this.usersDetails = data;
    });
  }

  goToOrgUsers() {
    window.open(this.usersDetails.link, '_blank');
  }  


}
