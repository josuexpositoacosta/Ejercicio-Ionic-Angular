import { Component, OnInit } from '@angular/core';

import { LoadingController } from '@ionic/angular';
import { PIonicService } from '../shared/p-ionic.service';

@Component({
  selector: 'app-post',
  templateUrl: './post.page.html',
  styleUrls: ['./post.page.scss'],
}) 
export class PostPage implements OnInit {
  Posts : any[] = [];
  postCount = null;
  page = 1;
 

  constructor(
    private pService: PIonicService, 
    private loadingController: LoadingController
  ) { }

  ngOnInit() {
    this.initPosts();
  }
 
  async initPosts() {
    let loading = await this.loadingController.create({
      message: 'Loading ...'
    });
 
    await loading.present();
 
    this.pService.getAllPosts().subscribe((data:any) => {
      this.postCount = this.pService.allPosts;
      this.Posts = data;
      loading.dismiss();
    });
  }
 
  infiniteLoad(e:any) {
    this.page++;
 
    this.pService.getAllPosts(this.page).subscribe((data) => {
      this.Posts = [...this.Posts, ...data];
      e.target.complete();
 
      // Disable loading when reached last
      if (this.page == this.pService.pages) {
        e.target.disabled = true;
      }
    });
  }

}
