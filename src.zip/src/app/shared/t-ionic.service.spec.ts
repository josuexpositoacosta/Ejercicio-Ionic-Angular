import { TestBed } from '@angular/core/testing';

import { TIonicService } from './t-ionic.service';

describe('TIonicService', () => {
  let service: TIonicService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(TIonicService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
