import { TestBed } from '@angular/core/testing';

import { PIonicService } from './p-ionic.service';

describe('PIonicService', () => {
  let service: PIonicService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PIonicService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
