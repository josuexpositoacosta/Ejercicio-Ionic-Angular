import { TestBed } from '@angular/core/testing';

import { UIonicService } from './u-ionic.service';

describe('UIonicService', () => {
  let service: UIonicService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(UIonicService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
