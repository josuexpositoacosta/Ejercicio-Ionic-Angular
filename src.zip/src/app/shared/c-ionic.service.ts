import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';

import { URL_SERVICIOS } from '../config/config';

@Injectable({
  providedIn: 'root'
})
export class CIonicService {
  endpoint =    URL_SERVICIOS;  
  allComments = null;
  pages?: any;

  constructor(private httpClient: HttpClient) { }

  getAllComments(page = 1): Observable<any[]> {
    let options = {
      observe: "response" as 'body',
      params: {
        per_page: '6',
        page: ''+page
      }
    }; 
 
    return this.httpClient.get<any[]>(`${this.endpoint}comments?_embed`, options)
    .pipe(
      map(res => {               
        this.pages = (res as { [key: string]: any }) ['headers'].get('x-wp-totalpages') as any ;
        
        this.allComments = (res as { [key: string]: any }) ['headers'].get('x-wp-total') as any;
        return (res as { [key: string]: any }) ['body'] as any;
      })
    )
  }
 
  commentsDetails(id:any) {
    return this.httpClient.get(`${this.endpoint}comments/${id}?_embed`)
    .pipe(
      map((post) => {
        return post;
      })
    )
  }

}
