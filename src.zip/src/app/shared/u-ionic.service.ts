import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';

import { URL_SERVICIOS } from '../config/config';

@Injectable({
  providedIn: 'root'
})
export class UIonicService {
    //servidor configurado por defecto
    endpoint =    URL_SERVICIOS;  
    allUsers = null;
    pages?: any;

    constructor(private httpClient: HttpClient) {  }

    getAllUsers(page = 1): Observable<any[]> {
      let options = {
        observe: "response" as 'body',
        params: {
          per_page: '6',
          page: ''+page
        }
      }; 
   
      return this.httpClient.get<any[]>(`${this.endpoint}users?_embed`, options)
      .pipe(
        map(res => {          
          this.pages = (res as { [key: string]: any }) ['headers'].get('x-wp-totalpages') as any ;          
          this.allUsers = (res as { [key: string]: any }) ['headers'].get('x-wp-total') as any;
          return (res as { [key: string]: any }) ['body'] as any;
        })
      )
    }
   
    usersDetails(id:any) {
      return this.httpClient.get(`${this.endpoint}users/${id}?_embed`)
      .pipe(
        map((post) => {
          return post;
        })
      )
    }

}
