import { TestBed } from '@angular/core/testing';

import { CIonicService } from './c-ionic.service';

describe('CIonicService', () => {
  let service: CIonicService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CIonicService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
