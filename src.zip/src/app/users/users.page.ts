import { Component, OnInit } from '@angular/core';

import { LoadingController } from '@ionic/angular';
import { UIonicService } from '../shared/u-ionic.service';


@Component({
  selector: 'app-users',
  templateUrl: './users.page.html',
  styleUrls: ['./users.page.scss'],
})
export class UsersPage implements OnInit {
  Users : any[] = [];
  usersCount = null;
  page = 1;
  constructor(
    private uService: UIonicService, 
    private loadingController: LoadingController
  ) {
 
   }

  ngOnInit() {
    this.initUsers();
  }


  async initUsers() {
    let loading = await this.loadingController.create({
      message: 'Loading ...'
    });
 
    await loading.present();
 
    this.uService.getAllUsers().subscribe((data:any) => {
      this.usersCount = this.uService.allUsers;
      this.Users = data;
      loading.dismiss();
    });
  }
 
  infiniteLoad(e:any) {
    this.page++;
 
    this.uService.getAllUsers(this.page).subscribe((data) => {
      this.Users = [...this.Users, ...data];
      e.target.complete();
 
      // Disable loading when reached last
      if (this.page == this.uService.pages) {
        e.target.disabled = true;
      }
    });
  }


}
