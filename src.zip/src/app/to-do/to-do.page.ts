import { Component, OnInit } from '@angular/core';
import { LoadingController } from '@ionic/angular';
import { TIonicService } from '../shared/t-ionic.service';

@Component({
  selector: 'app-to-do',
  templateUrl: './to-do.page.html',
  styleUrls: ['./to-do.page.scss'],
})
export class ToDoPage implements OnInit {
  Todos : any[] = [];
  todosCount = null;
  page = 1;

  constructor(
    private tService: TIonicService, 
    private loadingController: LoadingController
  ) { }

  ngOnInit() {
    this.initTodos();
  }

  async initTodos() {
    let loading = await this.loadingController.create({
      message: 'Loading ...'
    });
 
    await loading.present();
 
    this.tService.getAllTodos().subscribe((data:any) => {
      this.todosCount = this.tService.allTodos;
      this.Todos = data;
      loading.dismiss();
    });
  }
 
  infiniteLoad(e:any) {
    this.page++;
 
    this.tService.getAllTodos(this.page).subscribe((data) => {
      this.Todos = [...this.Todos, ...data];
      e.target.complete();
 
      // Disable loading when reached last
      if (this.page == this.tService.pages) {
        e.target.disabled = true;
      }
    });
  }


}
