import { Component } from '@angular/core';


import { Platform } from '@ionic/angular';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent {
  showSubmenu: boolean = false;
  showSubmenu1: boolean = false;
  showSubmenu2: boolean = false;
  showSubmenu3: boolean = false;

  activeIndex ?: number;
  activePageTitle = 'folder/';
  Pages = [
    {
      title: 'users',
      url: '/users',
      icon: 'person'
    },
    {
      title: 'post',
      url: '/post',
      icon: 'person'
    },
    {
      title: 'comments',
      url: '/comments',
      icon: 'person'
    },
    {
      title: 'to-do',
      url: '/to-do',
      icon: 'person'
    }
  ];


  
 // public appPages = [
  // { title: 'listar', url: 'users', icon: 'mail' },
  // {path: 'listar', component: UsuariosComponent, title: 'listar', icon: 'mail'}, //data:{ titulo : 'listar' } },     
  // { title: 'post', url: '/folder/Outbox', icon: 'paper-plane' },
  //  { title: 'Comments', url: '/folder/Favorites', icon: 'heart' },
   // { title: 'Todos', url: '/folder/Archived', icon: 'archive' },
  //  { title: 'Trash', url: '/folder/Trash', icon: 'trash' },
   // { title: 'Spam', url: '/folder/Spam', icon: 'warning' },
 // ];

 // public appPages1 = [
 //   { title: 'listar', url: '/folder/Inbox', icon: 'mail' },
  //  { title: 'por autor', url: '/folder/Outbox', icon: 'paper-plane' },
 //   { title: 'nueva ', url: '/folder/Favorites', icon: 'heart' },
  //  { title: 'eliminar ', url: '/folder/Archived', icon: 'archive' }, 
 // ];

 // public appPages2 = [
  //  { title: 'listar', url: '/folder/Inbox', icon: 'mail' },
  //  { title: 'eliminar', url: '/folder/Outbox', icon: 'paper-plane' },
   
 // ];

 // public appPages3 = [
  //  { title: 'listar', url: '/folder/Inbox', icon: 'mail' },
 //   { title: 'nueva ', url: '/folder/Outbox', icon: 'paper-plane' },
 //   { title: 'estado ', url: '/folder/Favorites', icon: 'heart' },
 //   { title: 'eliminar ', url: '/folder/Archived', icon: 'archive' }, 
 // ];
 // public labels = ['Family', 'Friends', 'Notes', 'Work', 'Travel', 'Reminders'];

  menuItemHandler(): void {
    this.showSubmenu = !this.showSubmenu;
  }

  menuItemHandler1(): void {
    this.showSubmenu1 = !this.showSubmenu1;
  }

  menuItemHandler2(): void {
    this.showSubmenu2 = !this.showSubmenu2;
  }

  menuItemHandler3(): void {
    this.showSubmenu3 = !this.showSubmenu3;
  }


  constructor(
    private platform: Platform,
    private statusBar: StatusBar,
    private splashScreen: SplashScreen,

  ) {
    this.initializeApp();
  } 

  initializeApp() {
    this.platform.ready().then(() => {
      this.statusBar.styleDefault();
      this.splashScreen.hide();
    });
  }
  
}
