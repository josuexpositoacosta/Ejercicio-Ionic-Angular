import { Component, OnInit } from '@angular/core';

import { LoadingController } from '@ionic/angular';
import { CIonicService } from '../shared/c-ionic.service';


@Component({
  selector: 'app-comments',
  templateUrl: './comments.page.html',
  styleUrls: ['./comments.page.scss'],
})
export class CommentsPage implements OnInit {
  Comments : any[] = [];
  commentsCount = null;
  page = 1;
  constructor(
    private cService: CIonicService, 
    private loadingController: LoadingController
  ) { }
 
  ngOnInit() {
    this.initComments();
  }

  async initComments() {
    let loading = await this.loadingController.create({
      message: 'Loading ...'
    });
 
    await loading.present();
 
    this.cService.getAllComments().subscribe((data:any) => {
      this.commentsCount = this.cService.allComments;
      this.Comments = data;
      loading.dismiss();
    });
  }
 
  infiniteLoad(e:any) {
    this.page++;
 
    this.cService.getAllComments(this.page).subscribe((data) => {
      this.Comments = [...this.Comments, ...data];
      e.target.complete();
 
      // Disable loading when reached last
      if (this.page == this.cService.pages) {
        e.target.disabled = true;
      }
    });
  }




}
